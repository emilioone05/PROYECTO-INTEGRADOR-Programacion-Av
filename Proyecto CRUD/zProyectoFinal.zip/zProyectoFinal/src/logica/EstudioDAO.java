package LOGICA;

import BD.Conexion;
import modelo.EstudioRenta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstudioDAO {

    private Connection conn;

    public EstudioDAO() throws SQLException {
        this.conn = Conexion.getConexion(); // ← Usamos la clase del paquete BD
    }

    public void insertar(EstudioRenta e) throws SQLException {
        String sql = "INSERT INTO estudio_rentas_provincia (codigo, provincia, region, modelo, uso_preferido, cantidad_rentas) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, e.getCodigo());
            stmt.setString(2, e.getProvincia());
            stmt.setString(3, e.getRegion());
            stmt.setString(4, e.getModelo());
            stmt.setString(5, e.getUsoPreferido());
            stmt.setInt(6, e.getCantidadRentas());
            stmt.executeUpdate();
        }
    }

    public List<EstudioRenta> listar() throws SQLException {
        List<EstudioRenta> lista = new ArrayList<>();
        String sql = "SELECT * FROM estudio_rentas_provincia";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                EstudioRenta e = new EstudioRenta(
                        rs.getInt("id"),
                        rs.getString("codigo"),
                        rs.getString("provincia"),
                        rs.getString("region"),
                        rs.getString("modelo"),
                        rs.getString("uso_preferido"),
                        rs.getInt("cantidad_rentas")
                );
                lista.add(e);
            }
        }
        return lista;
    }

//    public void actualizar(EstudioRenta e) throws SQLException {
//        String sql = "UPDATE estudio_rentas_provincia SET codigo=?, provincia=?, region=?, modelo=?, uso_preferido=?, cantidad_rentas=? WHERE id=?";
//        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
//            stmt.setString(1, e.getCodigo());
//            stmt.setString(2, e.getProvincia());
//            stmt.setString(3, e.getRegion());
//            stmt.setString(4, e.getModelo());
//            stmt.setString(5, e.getUsoPreferido());
//            stmt.setInt(6, e.getCantidadRentas());
//            stmt.setInt(7, e.getId());
//            stmt.executeUpdate();
//        }
//    }
    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM estudio_rentas_provincia WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public void actualizarCampoPorId(int id, String campo, String nuevoValor) throws SQLException {
        // Lista blanca de campos válidos para evitar SQL injection
        List<String> camposValidos = List.of("codigo", "provincia", "region", "modelo", "uso_preferido", "cantidad_rentas");

        if (!camposValidos.contains(campo)) {
            throw new IllegalArgumentException("Campo inválido: " + campo);
        }

        // Armar el SQL dinámicamente
        String sql = "UPDATE estudio_rentas_provincia SET " + campo + " = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Si el campo es cantidad_rentas, lo convertimos a int
            if (campo.equals("cantidad_rentas")) {
                stmt.setInt(1, Integer.parseInt(nuevoValor));
            } else {
                stmt.setString(1, nuevoValor);
            }
            stmt.setInt(2, id);
            stmt.executeUpdate();
        }
    }

    public List<EstudioRenta> listarCodigoProvincia() throws SQLException {
        List<EstudioRenta> lista = new ArrayList<>();
        String sql = "SELECT DISTINCT codigo, provincia FROM estudio_rentas_provincia";

        try (Connection conn = Conexion.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EstudioRenta estudio = new EstudioRenta();
                estudio.setCodigo(rs.getString("codigo"));
                estudio.setProvincia(rs.getString("provincia"));
                lista.add(estudio);
            }
        }

        return lista;
    }
}
