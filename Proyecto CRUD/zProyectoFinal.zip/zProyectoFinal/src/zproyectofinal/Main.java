
package zproyectofinal;
import vista.EstudioVista;
public class Main {
    public static void main(String[] args) {
        try {
            new EstudioVista();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}