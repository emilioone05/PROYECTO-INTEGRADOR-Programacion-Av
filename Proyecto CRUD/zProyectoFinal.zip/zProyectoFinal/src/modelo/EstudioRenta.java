package modelo;

public class EstudioRenta {
    private int id;
    private String codigo;
    private String provincia;
    private String region;
    private String modelo;
    private String usoPreferido;
    private int cantidadRentas;

    public EstudioRenta() {}

    public EstudioRenta(int id, String codigo, String provincia, String region, String modelo, String usoPreferido, int cantidadRentas) {
        this.id = id;
        this.codigo = codigo;
        this.provincia = provincia;
        this.region = region;
        this.modelo = modelo;
        this.usoPreferido = usoPreferido;
        this.cantidadRentas = cantidadRentas;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getProvincia() { return provincia; }
    public void setProvincia(String provincia) { this.provincia = provincia; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getUsoPreferido() { return usoPreferido; }
    public void setUsoPreferido(String usoPreferido) { this.usoPreferido = usoPreferido; }

    public int getCantidadRentas() { return cantidadRentas; }
    public void setCantidadRentas(int cantidadRentas) { this.cantidadRentas = cantidadRentas; }
    @Override
public String toString() {
    return codigo + " - " + provincia;
}

}
