/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
public class CodigoProvincia {
    private int codigo;
    private String provincia;

    public CodigoProvincia(int codigo, String provincia) {
        this.codigo = codigo;
        this.provincia = provincia;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getProvincia() {
        return provincia;
    }

    @Override
    public String toString() {
        return codigo + " - " + provincia;
    }
}
